﻿{
	"version": 1660626786,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/pngegg-sheet0.png",
		"images/Безимени-sheet0.png",
		"images/click-sheet0.png",
		"images/shop-sheet0.png",
		"images/ыв-sheet0.png",
		"images/da-sheet0.png",
		"images/video-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}